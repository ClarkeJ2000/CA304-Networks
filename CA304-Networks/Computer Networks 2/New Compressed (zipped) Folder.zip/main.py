import ipaddress
from typing import Optional
from fastapi import FastAPI
from ipaddress import IPv4Address, IPv4Network, ip_address
import urllib.request



#this code was taken from specification, although unsure where it was useful for 
classes={
'A':{

'network_bits':7,

'host_bits':24

},

'B':{

'network_bits':14,

'host_bits':16

},

'C':{

'network_bits':21,

'host_bits':8

},

'D':{

'network_bits':'N/A',

'host_bits':'N/A'

},

'E':{

'network_bits':'N/A',

'host_bits':'N/A'

},

}

app = FastAPI()


@app.post("/ipcalc")

async def ipcalc(address: str):
    #turn into format [192, 168, 0, 1]
    address = address.split(".")
    address[0] = int(address[0])
    #hard-code each response for each class
    if address[0] >= 0 and address[0] <= 127:
        return{
	        "Class": "A",
	        "num_networks": "126",
	        "num_hosts": "16777214",
	        "first_address": "0.0.0.0",
	        "last_address": "127.255.255.255"
        }

    elif address[0] >= 128 and address[0] <= 191:
       return {
	        "Class": "B",
	        "num_networks": "16384",
	        "num_hosts": "65536",
	        "first_address": "128.0.0.0",
	        "last_address": "191.255.255.255"
        }

    elif address[0] >= 192 and address[0] <= 223:
        return {
	        "Class": "C",
	        "num_networks": "16777214",
	        "num_hosts": "254",
	        "first_address": "192.0.0.0",
	        "last_address": "223.255.255.255"
        }
#for both classes D and E we have N/A at number of networks and number of hosts 
#this is because there are no host addresses within these class spaces
    elif address[0] >= 224 and address[0] <= 239:
        return {
	        "Class": "D",
	        "num_networks": "N/A",
	        "num_hosts": "N/A",
	        "first_address": "224.0.0.0",
	        "last_address": "239.255.255.255"
        }         

    elif address[0] >= 240 and address[0] <= 255:
        return {
	        "Class": "E",
	        "num_networks": "N/A",
	        "num_hosts": "N/A",
	        "first_address": "240.0.0.0",
	        "last_address": "255.255.255.255"
        }

@app.post("/subnet")
def subnet(address : str, mask : str):
	#split the mask on the decimal point
	mask = mask.split(".")
	address = address.strip()
	
	#converted each part into binary and puts it into a string
	mask1 = bin(int(mask[0]))
	mask2 = bin(int(mask[1]))
	mask3 = bin(int(mask[2]))
	mask4 = bin(int(mask[3])) #hostbit  
	
	binary_mask = str(mask1[2:]) + "." + str(mask2[2:]) + "." + str(mask3[2:]) + "." + str(mask4[2:])
	#count the number of network bits
	cidr = str(binary_mask.count("1"))  #bits that are set to 1

	subnets = 2 ** mask4.count("1")
	#to get this I had to use the formula of (2 x the number of host bits minus 2)
	#the host bits are located at the location x.x.x.hostbits
	hosts = str(2 ** mask4[2:].count("0") - 2)

	valid_subnets = str(address[:-2]) + "." + "64", str(address[:-2]) + "." + "128", str(address[:-2]) + "." + "192"

	#as stated in your notes, broadcast addresses are just subnets minus 1, and the subnets are 0,64,128,192
	#therefor the broadcast addresses are 63,127,255
	broadcast_addresses = str(address[:-2]) + "." + "63", str(address[:-2]) + "." + "127", str(address[:-2]) + "." + "191", str(address[:-2]) + "." + "255"
	#for first addresses and last addresses, the ip stays the same apart from the last digit, therefor I felt i could just hard code the response as it is always the same.
	first_address = str(address[:-2]) + "." + "1", str(address[:-2]) + "." + "65", str(address[:-2]) + "." + "129", str(address[:-2]) + "." + "193"

	last_address = str(address[:-2]) + "." + "62", str(address[:-2]) + "." + "126", str(address[:-2]) + "." + "190", str(address[:-2]) + "." + "254" 

	return{
		#return all the functions we made above
		"address_cidr: " + str(address.strip()) + "/" + str(cidr.strip()), #tried stripping them to remove ()s each side of the string 
		"num_subnets: " + str(subnets), 
		"addressable_hosts_per_subnet: " + str(hosts.strip()), 
		"valid_subnets: " + str(valid_subnets),
		"broadcast_addresses: " + "[" + str(broadcast_addresses) + "]", 
		"first_addresses: " + str(first_address), 
		"last_addresses: " + str(last_address)
		}

app.post("/supernet")
def supernet(addres: str, mask: str):
	mask = mask.split(".")
	address = address.strip()
	#code below taken from subnet, just to get cidr notation.
	#converted each part into binary and puts it into a string
	mask1 = bin(int(mask[0]))
	mask2 = bin(int(mask[1]))
	mask3 = bin(int(mask[2]))
	mask4 = bin(int(mask[3])) #hostbit  
	
	binary_mask = str(mask1[2:]) + "." + str(mask2[2:]) + "." + str(mask3[2:]) + "." + str(mask4[2:])
	#count the number of network bits
	cidr = str(binary_mask.count("1"))  #bits that are set to 1

	return{
		"address " + str(address.strip()) + "/" + str(cidr.strip(),
		"mask: " # unable to figure this part out
	}